function test1()
{
	var id = document.f1.id.value;
	if (id.length==0)
		alert('Entrer un id souhaiter');

}

