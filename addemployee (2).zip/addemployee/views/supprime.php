
<?PHP
include "../core/classeC.php";
$classeC= new classcC();
if (isset($_POST["idemp"])){
	$classeC->supprimerEmploye($_POST["idemp"]);
	header('Location: afficherEmploye.php');
}

?>
