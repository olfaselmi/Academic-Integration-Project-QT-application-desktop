

	<html>
<head>
	<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Dashio - Bootstrap Admin Template</title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
</head>
	
<div class="sidenav">
    <a href="index.html">ADD</a>
    <a href="afficherEmploye.php">SELECT</a>
    <a href="start.php">DELETE</a>
    <a href="MODIFER.php">UPDATE</a>
    <a href="metier1.html"> CHERCHER</a>
    <a href="metier2.html"> TRIER</a>
    <a href="email.php"> EMAIL</a>
        </div>

<body>


	</div>
	<dir class="main">

		
	
	<div class="card-content">
						<h1></h1>
	
	<center>
<h4 class="sent-notification"></h4>
  <form id="myForm">
  <h2>Send an Email</h2>

  <label>Name</label>
  <input id="name" type="text" placeholder="Enter Name">
  <br><br>
  <label>Email</label>
  <input id="email" type="text" placeholder="Enter Email">
  <br><br>
  <label>Subject</label>
  <input id="subject" type="text" placeholder=" Enter Subject"> 
  <br><br>
  <p>Message</p>
  <textarea id="body" rows="10" cols="100" placeholder="Type Message"></textarea>
  <br><br>
  <button type="button" onclick="sendEmail()" value="Send An Email">Submit</button> 

  </form>
</center>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

<script type="text/javascript">
  function sendEmail(){
    var name = $("#name");
    var email = $("#email");
    var subject = $("#subject");
    var body = $("#body");

    if(isNotEmpty(name) && isNotEmpty(email) && isNotEmpty(subject) && isNotEmpty(body)){
      $.ajax({
        url: 'sendEmail.php',
        method: 'POST',
        dataType: 'json',
        data:{
          name: name.val(),
          email: email.val(),
          subject: subject.val(),
          body: body.val()
        }, success: function(response){
          $('#myForm')[0].reset();
          $('.sent-notification').text("Message sent successfully.");
        }
      });
    }
  }
  function isNotEmpty(caller){
    if(caller.val() == ""){
      caller.css('border','1px solid red');
      return false;
    }
    else
    {
      caller.css('border', '');
      return true;
    }
  }
</script>
</table>



</body>
</html>