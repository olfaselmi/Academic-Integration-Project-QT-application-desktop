<?PHP

include "../core/classeC.php";

foreach ($_POST['a'] as $selected)
if (isset($_POST['idemp']) and isset($selected) and isset($_POST['nomemp']) and isset($_POST['prenomemp']) and isset($_POST['loginemp']) and isset($_POST['mdpemp']) ){

$classe1=new classe(($_POST['idemp']),$selected, $_POST['nomemp'], $_POST['prenomemp'], $_POST['loginemp'], $_POST['mdpemp']);

$classeC= new classcC();
$classeC-> ajouterclasse($classe1);
	header('Location: afficherEmploye.php');

}
//*/

?>