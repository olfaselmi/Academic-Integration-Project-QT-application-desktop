<HTML>
<head>
</head>
<body>
<?PHP


?>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="widempth=device-widempth, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluidemp, Retina">
  <title>Dashio - Bootstrap Admin Template</title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
</head>


<body>

	<div class="sidempenav">
		<a href="index.html">ADD</a>
		<a href="afficherEmploye.php">SELECT</a>
		<a href="start.php">DELTE</a>
		<a href="MODIFER.php">UPDATE</a>
    <a href="metier1.html"> CHERCHER</a>
    <a href="metier2.html"> TRIER</a>
    <a href="email.php"> EMAIL</a>
	</div>
	<dir class="main">
		<div class="card-content">
			<div class="limiter">
		<div class="container-loginemp100">
			
				<form class="loginemp100-form validempate-form"  method="POST" >
					<span class="loginemp100-form-title">
						Member Loginemp
					</span>

					<input type="text" class="form-control" name="idemp" placeholder="User IDemp" autofocus>
          <br>
          <input type="text" class="form-control" name="nomemp" placeholder="nomemp" autofocus>
          <br>
          <input type="text" class="form-control" name="prenomemp" placeholder="prenomemp" autofocus>
          <br>
          <input type="text" class="form-control" name="loginemp" placeholder="loginemp" autofocus>
          <br>
          <input type="password" class="form-control" name="mdpemp" placeholder="mot de passe" autofocus>
          <br>

          <h2>Niveau</h2>

          <label class="checkbox">
          <input  type="checkbox" name="a[]" value="debutant"/> debutant<br/>
          <input type="checkbox" name="a[]" value="intermediaire"/> intermediaire<br/>
          <input type="checkbox" name="a[]" value="avance"/> avance<br/>
            </label>
       
					
			

</html>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidempden" name="idemp_ini" value="<?PHP echo $_GET['idemp'];?>"></td>
</tr>
</table>
</form>
<?PHP

include "../core/classeC.php";

if (isset($_POST['modifier'])){
	foreach($_POST['a'] as $selected)

	$classeC= new classcC();
	$classe=new classe($_POST['idemp'],$selected,$_POST['nomemp'],$_POST['prenomemp'],$_POST['loginemp'],$_POST['mdpemp']);
	$classeC->modifierEmploye($classe,$_POST['idemp_ini']);
header('Location: afficherEmploye.php');
}
?>
