function test()
{
	var login = document.f1.login.value;
	var mdp = document.f1.mdp.value;
	if (login.length==0 || mdp.length==0)
		alert('merci de remplir ce formulaire');

else
{
	var p='.';
	var ad='@';
	var prenom=login.substring(0,login.indexOf(p));
	var nom=login.substring(login.indexOf(p)+1,login.indexOf(ad));
	alert("bienvenue"+" "+prenom+" "+nom);
}
}



