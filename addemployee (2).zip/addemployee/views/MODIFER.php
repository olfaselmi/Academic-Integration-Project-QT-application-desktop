<?PHP
include "../core/classeC.php";
$classeC= new classcC();
$listeEmployes=$classeC->affiche();

//var_dump($listeEmployes->fetchAll());
?>
<title>clubs</title>
	<link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">

<script type="text/javascript" language="javascript" src="function.js"></script>


</head>
<body>
	<div class="sidempenav">
		<a href="index.html">ADD</a>
		<a href="afficherEmploye.php">SELECT</a>
		<a href="start.php">DELTE</a>
		<a href="#">UPDATE</a>
		<a href="metier1.html"> CHERCHER</a>
		<a href="metier2.html"> TRIER</a>
		<a href="email.php"> EMAIL</a>
	</div>

	<dir class="main">
		<div class="card-content">
			<div class="limiter">	   
		<div class="container-loginemp100">
		
<table border="1">

<tr>

<th>idemp</th> 

<th>typeemp</th>

<th>nomemp</th>

<th>prenomemp</th>

<th>loginemp</th>

<th>mdpemp</th>

<th> UPDATE</TH>
</tr>
</div>
<?PHP
foreach($listeEmployes as $row){
	?>
	
	<tr>
	<td><?PHP echo $row['idemp']; ?></td>
	<td><?PHP echo $row['typeemp']; ?></td>
	<td><?PHP echo $row['nomemp']; ?></td>
	<td><?PHP echo $row['prenomemp']; ?></td>
	<td><?PHP echo $row['loginemp']; ?></td>
	<td><?PHP echo $row['mdpemp']; ?></td>

	
					<div class="container-loginemp100-form-btn">
					
	<td><a   class="btn btn-theme btn-block" class="loginemp100-form-btn" href="modifierEmploye.php?idemp=<?PHP echo $row['idemp']; ?>">
UPDATE</a></td>
	</form>
	
	</tr>
	<?PHP
}
?>
</table>

</body>