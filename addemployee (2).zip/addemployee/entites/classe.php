<?PHP
class classe{
	private $idemp;
	private $typeemp;
	private $nomemp;
	private $prenomemp;
	private $loginemp;
	private $mdpemp;
	
	function __construct($idemp,$typeemp,$nomemp,$prenomemp,$loginemp,$mdpemp){
		$this->idemp=$idemp;
		$this->typeemp=$typeemp;
		$this->nomemp=$nomemp;
		$this->prenomemp=$prenomemp;
		$this->loginemp=$loginemp;
		$this->mdpemp=$mdpemp;

	}
	
	function getidemp(){
		return $this->idemp;
	}
	function gettypeemp(){
		return $this->typeemp;
	}
	function getnomemp(){
		return $this->nomemp;
	}
	function getprenomemp(){
		return $this->prenomemp;
	}
	function getloginemp(){
		return $this->loginemp;
	}
	function getmdpemp(){
		return $this->mdpemp;
	}
}

?>