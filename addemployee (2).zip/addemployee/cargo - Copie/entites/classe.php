<?PHP
class classe{

	private $depart;
	private $id;
	private $arrive;
	private $type;
	
	
	function __construct($id,$type,$arrive,$depart){
		
	$this->id=$id;
	$this->arrive=$arrive;
	$this->type=$type;
		$this->depart=$depart;

	}
	
	function getarrive(){
		return $this->arrive;
	}
	function getdepart(){
		return $this->depart;
	}
	function getid(){
		return $this->id;
	}
	
	function gettypee(){
		return $this->type;
	}
	
}

?>