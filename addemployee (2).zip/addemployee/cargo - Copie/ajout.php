<?PHP

include "classeC.php";

{

foreach($_POST['a'] as $s)
$var = $_POST['taskOption'];
$v = $_POST['tas'];

$classe1=new classe(($_POST['id']),$s,$var,$v);

$classeC= new classcC();
$classeC-> ajouterclasse($classe1);
echo"livraison envoyée";

	

}
//*/

?>