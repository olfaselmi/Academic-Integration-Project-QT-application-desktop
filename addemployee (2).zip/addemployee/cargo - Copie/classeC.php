<?PHP
include "config.php";
include "entites/classe.php";
class classcC {

	function ajouterclasse($classe){
		$sql="insert into livraison (id,type,depart,arrive) values (:cin, :nom,:a,:b)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $cin=$classe->getid(); 
        $nom=$classe->gettypee();
		$a=$classe->getdepart();
       		$b=$classe->getarrive();
					
		$req->bindValue(':cin',$cin);
		$req->bindValue(':nom',$nom);
		
		$req->bindValue(':a',$a);
			$req->bindValue(':b',$b);
				
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	function clacule(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="  SElECT COUNT(id) AS s FROM livraison where type='expresse'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
		function claculec(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="  SElECT COUNT(id) AS sa FROM livraison where type='standard'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

	}
	
	






?>