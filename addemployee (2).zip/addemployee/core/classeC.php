s<?PHP
include "../config.php";
include "../entites/classe.php";
class classcC {

	function ajouterclasse($classe){
		$sql="insert into  employee (idemp,typeemp,nomemp,prenomemp,loginemp,mdpemp) values (:idemp, :typeemp,:nomemp,:prenomemp,:loginemp,:mdpemp)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $idemp=$classe->getidemp(); 
        $typeemp=$classe->gettypeemp();
        $nomemp=$classe->getnomemp();
        $prenomemp=$classe->getprenomemp();
        $loginemp=$classe->getloginemp();
        $mdpemp=$classe->getmdpemp();
       
		$req->bindValue(':idemp',$idemp);
		$req->bindValue(':typeemp',$typeemp);
		$req->bindValue(':nomemp',$nomemp);
		$req->bindValue(':prenomemp',$prenomemp);
		$req->bindValue(':loginemp',$loginemp);
		$req->bindValue(':mdpemp',$mdpemp);
	
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	function affiche(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From employee";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerEmploye($idemp){
		$sql="DELETE FROM employee where idemp= :idemp";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':idemp',$idemp);
		try{
            $req->execute();
           // header('Location: index.php');
        }
		catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	

	}

	function recupererEmploye($idemp){
		$sql="SELECT * from employee where idemp=$idemp";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
} 


function modifierEmploye($classe,$idemp){
		$sql="UPDATE employee SET idemp=:cinn, typeemp=:typeemp,nomemp=:nomemp,prenomemp=:prenomemp,loginemp=:loginemp,mdpemp=:mdpemp WHERE idemp=:idemp";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$cinn=$classe->getidemp();
        $typeemp=$classe->gettypeemp();
        $nomemp=$classe->getnomemp();
        $prenomemp=$classe->getprenomemp();
        $loginemp=$classe->getloginemp();
        $mdpemp=$classe->getmdpemp();
        
       
		$datas = array(':cinn'=>$cinn, ':idemp'=>$idemp, ':typeemp'=>$typeemp,':nomemp'=>$nomemp,':prenomemp'=>$prenomemp,':loginemp'=>$loginemp,':mdpemp'=>$mdpemp);
		$req->bindValue(':cinn',$cinn);
		$req->bindValue(':idemp',$idemp);
		$req->bindValue(':typeemp',$typeemp);
		$req->bindValue(':nomemp',$nomemp);
		$req->bindValue(':prenomemp',$prenomemp);
		$req->bindValue(':loginemp',$loginemp);
		$req->bindValue(':mdpemp',$mdpemp);

		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
		catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
        
        }


        function rechercherListeEmployes($idemp){
		$sql="SELECT * from employee where idemp=$idemp";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	    }


       public function trier()
      {
        $sql = "SELECT * From employee Order by typeemp";
        $db = config::getConnexion();
        try {
            $sth = $db->prepare($sql);
            $sth->execute();
            $liste = $sth->fetchAll();
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
      }

      function calculerduree()
      {
      	$sql = "SELECT myd FROM employee where idemp=$idemp";
        $db = config::getConnexion();
       $db = config::getConnexion();
        try {
            $sth = $db->prepare($sql);
            $sth->execute();
            $liste = $sth->fetchAll();
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }

      }



      
		
	}

?>