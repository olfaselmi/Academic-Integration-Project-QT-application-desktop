#include "son.h"

void  mettreMusique()
{
    QMediaPlayer * music=new QMediaPlayer();
    music->setMedia(QUrl("qrc:/music.mp3"));
    music->play();
}
