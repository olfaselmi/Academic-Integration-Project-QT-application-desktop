#ifndef CONNECTION_H
#define CONNECTION_H
#include <QSqlDatabase>

class Connexion
{
private:
    QSqlDatabase db ;
public:
    Connexion();
    bool ouvrirConnexion();
    void fermerConnexion();
};
#endif // CONNECTION_H
