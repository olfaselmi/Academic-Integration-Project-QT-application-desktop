#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include "connection.h"
#include <QtDebug>
#include "son.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Connexion c;
    mettreMusique();
    bool test=c.ouvrirConnexion();
    MainWindow w;
    if(test)
    {w.show();}
    else
    {
        QMessageBox::critical(nullptr ,QObject::tr("database is not open"),QObject::tr("connection failed ." "Click Cancel to exit"),QMessageBox::Cancel);
    }

    return a.exec();
}
