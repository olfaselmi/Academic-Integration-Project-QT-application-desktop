#ifndef SON_H
#define SON_H
#include <QMediaPlayer>

void mettreMusique();

#endif // SON_H
