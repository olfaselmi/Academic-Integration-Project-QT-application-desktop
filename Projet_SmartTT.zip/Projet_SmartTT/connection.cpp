#include "connection.h"
#include "exception"
#include <QSqlError>

Connexion::Connexion()
{

}
bool Connexion::ouvrirConnexion()
{
    bool test= false ;
      QSqlDatabase db =  QSqlDatabase::addDatabase("QODBC");
      db.setDatabaseName("Source_Projet2A");
      db.setUserName("hr");
      db.setPassword("hr");
      if(db.open())
      test=true ;
      return  test ;



}


void Connexion::fermerConnexion()
{
    db.close();
}
