#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "circuit.h"
#include "reseau.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
  void  playmusic();

private slots:
    void on_pushButton_ajoutercircuit_clicked();

    void on_pushButton_clicked();

    void on_pushButton_modifeir_clicked();
    void on_pushButton_modifeir_2_clicked();
    void on_pushButton_2_clicked();
    void on_toolButton_ajouterreseau_2_clicked();
    void on_lineEdit_idchercher_textChanged(const QString &arg1);


private:
    Ui::MainWindow *ui;
    circuit * tmp;
};

#endif // MAINWINDOW_H
