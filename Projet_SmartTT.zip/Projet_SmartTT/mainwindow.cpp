#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "circuit.h"
#include "reseau.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlQueryModel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
     ui->tableView_afficher->setModel(tmp->afficher());

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_ajoutercircuit_clicked()
{
    int id= ui->lineEdit_id->text().toInt();
    QString depart= ui->lineEdit_depart->text();
    QString arrivee= ui->lineEdit_arrivee->text();
    circuit C(id,depart,arrivee);
    bool text=C.ajouter();
    if(text)
    {
        QMessageBox::information(this,"Ajouter","reussie");
        ui->tableView_afficher->setModel(C.afficher());
    }
    else
    {
        QMessageBox::critical(this,"ajouter","echec!");
    }
}

void MainWindow::on_pushButton_clicked()
{
   int id=ui->lineEdit_idsupp->text().toInt ();
    circuit c;
    if(c.supprimer(id))
    {
        QMessageBox::information(this,"supprimer","reussie");
        ui->tableView_afficher->setModel(c.afficher());
    }
else
{
QMessageBox::critical(this,"supprimer","echec!");
}
}

void MainWindow::on_pushButton_modifeir_clicked()
{
    int id= ui->lineEdit_id_2->text().toInt();
    QString depart= ui->lineEdit_depart_2->text();
    QString arrivee= ui->lineEdit_arrivee_2->text();
    circuit C(id,depart,arrivee);
    bool text=C.modifier(id);
    if(text)
    {
        QMessageBox::information(this,"Ajouter","reussie");
        ui->tableView_afficher->setModel(C.afficher());
    }
    else
    {
        QMessageBox::critical(this,"ajouter","echec!");
    }
}


void MainWindow::on_lineEdit_idchercher_textChanged(const QString &arg1)
{
    circuit C;
    ui->tableView_afficher_2->setModel(C.rechercher(arg1));
}

void MainWindow::on_toolButton_ajouterreseau_2_clicked()
{
    int no= ui->lineEdit_id_3->text().toInt();
    int nb_circuit= ui->lineEdit_depart_3->text().toInt();
    QString type= ui->lineEdit_arrivee_3->text();
    reseau R(no,nb_circuit,type);
    bool text=R.ajouter();
    if(text)
    {
        QMessageBox::information(this,"Ajouter","reussie");
        ui->tableView_afficher_3->setModel(R.afficher());
    }
    else
    {
        QMessageBox::critical(this,"ajouter","echec!");
    }

}

void MainWindow::on_pushButton_2_clicked()
{
    int id=ui->lineEdit_idsupp_2->text().toInt();
     reseau d;
     if(d.supprimer(id))
     {
         QMessageBox::information(this,"supprimer","reussie");
         ui->tableView_afficher_3->setModel(d.afficher());
     }
 else
 {
 QMessageBox::critical(this,"supprimer","echec!");
 }

}

void MainWindow::on_pushButton_modifeir_2_clicked()
{
    int id= ui->lineEdit_id_4->text().toInt();
    int nb_circuit= ui->lineEdit_depart_4->text().toInt();
    QString type= ui->lineEdit_arrivee_4->text();
    reseau R(id,nb_circuit,type);
    bool text=R.modifier(id);
    if(text)
    {
        QMessageBox::information(this,"Ajouter","reussie");
        ui->tableView_afficher_3->setModel(R.afficher());
    }
    else
    {
        QMessageBox::critical(this,"ajouter","echec!");
    }
}
